export type Role = 'admin' | 'investigator' | 'viewer';

export interface User {
  id: string;
  email: string;
  role: Role;
  district?: string;
  state?: string;
}

export interface Criminal {
  id: string;
  state: string;
  district: string;
  policeStation: string;
  firNumber: string;
  name: string;
  age: number;
  fatherName: string;
  gender: 'male' | 'female' | 'other';
  address: string;
  idProof: {
    type: 'aadhar' | 'pan' | 'voter';
    number: string;
  };
  identifiableMarks: string[];
  warrants: Warrant[];
  created_at: string;
  updated_at: string;
  created_by: string;
  updated_by: string;
}

export interface Warrant {
  id: string;
  criminalId: string;
  issueDate: string;
  details: string;
  status: 'active' | 'inactive';
  issuingAuthority: string;
}