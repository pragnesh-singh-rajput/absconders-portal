import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Search, Filter, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import type { Criminal } from '../types';

function CriminalList() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [criminals, setCriminals] = useState<Criminal[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    state: '',
    district: '',
    warrantStatus: '',
    ageRange: '',
    gender: ''
  });

  const canAddNew = ['admin', 'investigator'].includes(user?.role || '');
  const canUpdateStatus = ['admin', 'investigator'].includes(user?.role || '');

  useEffect(() => {
    fetchCriminals();
  }, [user, filters]);

  const fetchCriminals = async () => {
    try {
      let query = supabase
        .from('criminals')
        .select(`
          *,
          warrants (
            id,
            issue_date,
            details,
            status,
            issuing_authority
          ),
          id_proofs (
            type,
            number
          ),
          identifiable_marks (
            description,
            mark_type,
            location
          )
        `);

      // Apply filters
      if (filters.state) query = query.eq('state', filters.state);
      if (filters.district) query = query.eq('district', filters.district);
      if (filters.gender) query = query.eq('gender', filters.gender);
      if (filters.warrantStatus) {
        query = query.eq('warrants.status', filters.warrantStatus);
      }

      const { data, error } = await query;

      if (error) throw error;
      setCriminals(data || []);
    } catch (error) {
      console.error('Error fetching criminals:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateWarrantStatus = async (criminalId: string, warrantId: string, newStatus: 'active' | 'inactive') => {
    try {
      const { error } = await supabase
        .from('warrants')
        .update({ status: newStatus })
        .eq('id', warrantId)
        .eq('criminal_id', criminalId);

      if (error) throw error;
      fetchCriminals();
    } catch (error) {
      console.error('Error updating warrant status:', error);
    }
  };

  const filteredCriminals = criminals.filter(criminal => {
    const searchString = searchTerm.toLowerCase();
    return (
      criminal.name.toLowerCase().includes(searchString) ||
      criminal.firNumber.toLowerCase().includes(searchString) ||
      criminal.fatherName.toLowerCase().includes(searchString) ||
      criminal.identifiable_marks?.some(mark => 
        mark.description.toLowerCase().includes(searchString)
      )
    );
  });

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-semibold text-gray-900">Absconders List</h1>
            {canAddNew && (
              <button
                onClick={() => navigate('/criminals/new')}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                <Plus className="h-5 w-5 mr-2" />
                Add New Record
              </button>
            )}
          </div>

          {/* Search and Filters */}
          <div className="mt-4 space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                    placeholder="Search by name, FIR number, or identifiable marks..."
                  />
                </div>
              </div>
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                {showFilters ? <X className="h-5 w-5 mr-2" /> : <Filter className="h-5 w-5 mr-2" />}
                {showFilters ? 'Hide Filters' : 'Show Filters'}
              </button>
            </div>

            {showFilters && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 bg-white p-4 rounded-md shadow">
                <div>
                  <label htmlFor="state" className="block text-sm font-medium text-gray-700">State</label>
                  <select
                    id="state"
                    value={filters.state}
                    onChange={(e) => setFilters(f => ({ ...f, state: e.target.value }))}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  >
                    <option value="">All States</option>
                    {/* Add state options */}
                  </select>
                </div>
                <div>
                  <label htmlFor="district" className="block text-sm font-medium text-gray-700">District</label>
                  <select
                    id="district"
                    value={filters.district}
                    onChange={(e) => setFilters(f => ({ ...f, district: e.target.value }))}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  >
                    <option value="">All Districts</option>
                    {/* Add district options */}
                  </select>
                </div>
                <div>
                  <label htmlFor="warrantStatus" className="block text-sm font-medium text-gray-700">Warrant Status</label>
                  <select
                    id="warrantStatus"
                    value={filters.warrantStatus}
                    onChange={(e) => setFilters(f => ({ ...f, warrantStatus: e.target.value }))}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  >
                    <option value="">All</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="gender" className="block text-sm font-medium text-gray-700">Gender</label>
                  <select
                    id="gender"
                    value={filters.gender}
                    onChange={(e) => setFilters(f => ({ ...f, gender: e.target.value }))}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  >
                    <option value="">All</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          {/* Records Table */}
          <div className="mt-8 flex flex-col">
            <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
              <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Name
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          FIR Number
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          District
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th scope="col" className="relative px-6 py-3">
                          <span className="sr-only">Actions</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {loading ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-4 text-center">
                            Loading...
                          </td>
                        </tr>
                      ) : filteredCriminals.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-4 text-center">
                            No records found
                          </td>
                        </tr>
                      ) : (
                        filteredCriminals.map((criminal) => (
                          <tr key={criminal.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium text-gray-900">{criminal.name}</div>
                              <div className="text-sm text-gray-500">s/o {criminal.fatherName}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{criminal.firNumber}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{criminal.district}</div>
                              <div className="text-sm text-gray-500">{criminal.state}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {criminal.warrants?.map((warrant) => (
                                <div key={warrant.id} className="flex items-center space-x-2">
                                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                    warrant.status === 'active' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                                  }`}>
                                    {warrant.status === 'active' ? 'Active Warrant' : 'Case Closed'}
                                  </span>
                                  {canUpdateStatus && warrant.status === 'active' && (
                                    <button
                                      onClick={() => updateWarrantStatus(criminal.id, warrant.id, 'inactive')}
                                      className="text-xs text-indigo-600 hover:text-indigo-900"
                                    >
                                      Close Case
                                    </button>
                                  )}
                                </div>
                              ))}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <button
                                onClick={() => navigate(`/criminals/${criminal.id}`)}
                                className="text-indigo-600 hover:text-indigo-900"
                              >
                                View Details
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CriminalList;