import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import CriminalList from './pages/CriminalList';
import CriminalForm from './pages/CriminalForm';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-100">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/criminals"
              element={
                <ProtectedRoute>
                  <CriminalList />
                </ProtectedRoute>
              }
            />
            <Route
              path="/criminals/new"
              element={
                <ProtectedRoute allowedRoles={['admin', 'investigator']}>
                  <CriminalForm />
                </ProtectedRoute>
              }
            />
            <Route
              path="/criminals/:id"
              element={
                <ProtectedRoute>
                  <CriminalForm />
                </ProtectedRoute>
              }
            />
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App