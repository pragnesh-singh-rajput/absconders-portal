/*
  # Initial Schema Setup for Absconder Portal

  1. New Tables
    - `criminals`
      - Basic information about criminals
      - Includes personal details, location info, and timestamps
    - `warrants`
      - Warrant information linked to criminals
      - Tracks status and details of each warrant
    - `identifiable_marks`
      - Stores unique identifiable marks for criminals
    - `id_proofs`
      - Stores identification documents for criminals

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users based on role and jurisdiction
*/

-- Create criminals table
CREATE TABLE IF NOT EXISTS criminals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  state text NOT NULL,
  district text NOT NULL,
  police_station text NOT NULL,
  fir_number text NOT NULL,
  name text NOT NULL,
  age int NOT NULL,
  father_name text NOT NULL,
  gender text NOT NULL CHECK (gender IN ('male', 'female', 'other')),
  address text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id),
  updated_by uuid REFERENCES auth.users(id)
);

-- Create warrants table
CREATE TABLE IF NOT EXISTS warrants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  criminal_id uuid REFERENCES criminals(id) ON DELETE CASCADE,
  issue_date timestamptz NOT NULL,
  details text NOT NULL,
  status text NOT NULL CHECK (status IN ('active', 'inactive')),
  issuing_authority text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id)
);

-- Create identifiable_marks table
CREATE TABLE IF NOT EXISTS identifiable_marks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  criminal_id uuid REFERENCES criminals(id) ON DELETE CASCADE,
  description text NOT NULL,
  mark_type text NOT NULL,
  location text NOT NULL
);

-- Create id_proofs table
CREATE TABLE IF NOT EXISTS id_proofs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  criminal_id uuid REFERENCES criminals(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('aadhar', 'pan', 'voter')),
  number text NOT NULL,
  UNIQUE(type, number)
);

-- Enable RLS
ALTER TABLE criminals ENABLE ROW LEVEL SECURITY;
ALTER TABLE warrants ENABLE ROW LEVEL SECURITY;
ALTER TABLE identifiable_marks ENABLE ROW LEVEL SECURITY;
ALTER TABLE id_proofs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view criminals in their jurisdiction"
  ON criminals
  FOR SELECT
  TO authenticated
  USING (
    (auth.jwt() ->> 'role' = 'admin') OR
    (auth.jwt() ->> 'state' = state AND auth.jwt() ->> 'district' = district)
  );

CREATE POLICY "Authorized users can insert criminals"
  ON criminals
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.jwt() ->> 'role' IN ('admin', 'investigator')
  );

CREATE POLICY "Authorized users can update criminals in their jurisdiction"
  ON criminals
  FOR UPDATE
  TO authenticated
  USING (
    (auth.jwt() ->> 'role' = 'admin') OR
    (auth.jwt() ->> 'state' = state AND auth.jwt() ->> 'district' = district)
  );

-- Similar policies for other tables
CREATE POLICY "Users can view warrants"
  ON warrants
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authorized users can insert warrants"
  ON warrants
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.jwt() ->> 'role' IN ('admin', 'investigator')
  );

-- Create functions for dashboard stats
CREATE OR REPLACE FUNCTION get_dashboard_stats(user_state text, user_district text, user_role text)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  active_warrants integer;
  total_criminals integer;
  recent_arrests integer;
BEGIN
  -- Get stats based on user's jurisdiction
  IF user_role = 'admin' THEN
    SELECT COUNT(*) INTO active_warrants FROM warrants WHERE status = 'active';
    SELECT COUNT(*) INTO total_criminals FROM criminals;
    SELECT COUNT(*) INTO recent_arrests 
    FROM warrants 
    WHERE status = 'inactive' 
    AND updated_at > now() - interval '30 days';
  ELSE
    SELECT COUNT(*) INTO active_warrants 
    FROM warrants w
    JOIN criminals c ON w.criminal_id = c.id
    WHERE w.status = 'active'
    AND c.state = user_state
    AND c.district = user_district;

    SELECT COUNT(*) INTO total_criminals 
    FROM criminals
    WHERE state = user_state
    AND district = user_district;

    SELECT COUNT(*) INTO recent_arrests 
    FROM warrants w
    JOIN criminals c ON w.criminal_id = c.id
    WHERE w.status = 'inactive'
    AND c.state = user_state
    AND c.district = user_district
    AND w.updated_at > now() - interval '30 days';
  END IF;

  RETURN json_build_object(
    'active_warrants', active_warrants,
    'total_criminals', total_criminals,
    'recent_arrests', recent_arrests
  );
END;
$$;